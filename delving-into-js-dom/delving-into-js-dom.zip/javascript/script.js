let titles = document.getElementsByTagName("h2");
console.log(titles.length);

for (let index = 0; index < titles.length; index++) {
  let title = titles[index];
  title.innerHTML = '<span class="mono">- </span>' + title.innerText;
  title.addEventListener("click", clickHandle, true);
  
  let relatedDiv = title.nextElementSibling;
  let collapseMark = title.firstChild;
  collapseMark.innerText = "+ ";
  relatedDiv.setAttribute("style", "display:none");
}

function clickHandle(event) {
  let headerClicked = event.currentTarget;
  let relatedDiv = headerClicked.nextElementSibling;
  let collapseMark = headerClicked.firstChild; // <span class="mono">+ </span>
  let isCollapsed = collapseMark.innerText[0] == "+";
  collapseMark.innerText = isCollapsed ? "- " : "+ ";
  relatedDiv.setAttribute("style", isCollapsed ? "" : "display:none");
  headerClicked.setAttribute("style", "background-color:tomato");
}
